package users;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import application.Mongo;

public class UserResource {
	
	private Mongo dataBase = new Mongo();
	
	@GET
	@Path("user/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public User getUser(@PathParam("name") String username) {	
		User user = new User();
		user = dataBase.getUser(username);
		
		return user;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public User createTask(User user) {
		dataBase.insertUser(user);
		return user;
	}

	@PUT
	@Path("{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public User editUser(User user, @PathParam("id") int id) {
		dataBase.updateUser("plop", user);
		return user;
	}

	@DELETE
	@Path("{username}")
	@Produces(MediaType.APPLICATION_JSON)
	public int removeUser(@PathParam("username") String username) {
		dataBase.deleteUser(username);
		return 0;
	}

}
